const db = require('../db');

// Bloque l'acces si aucun marchand n'est connecte
function exigerConnexion(req, res, next) {
  if (!req.session.marchandId) {
    return res.redirect('/connexion');
  }
  const marchand = db.prepare('SELECT * FROM marchands WHERE id = ?').get(req.session.marchandId);
  if (!marchand) {
    req.session.destroy(() => {});
    return res.redirect('/connexion');
  }
  req.marchand = marchand;
  res.locals.marchand = marchand;
  next();
}

// Bloque l'acces au panneau admin si le mot de passe admin n'a pas ete saisi
function exigerAdmin(req, res, next) {
  if (!req.session.estAdmin) {
    return res.redirect('/admin/connexion');
  }
  next();
}

module.exports = { exigerConnexion, exigerAdmin };
