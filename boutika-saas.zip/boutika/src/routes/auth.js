const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db');
const { creerSlug } = require('../utils');

const router = express.Router();
const JOURS_ESSAI = Number(process.env.TRIAL_DAYS || 14);

router.get('/inscription', (req, res) => {
  if (req.session.marchandId) return res.redirect('/tableau-de-bord');
  res.render('signup', { erreurs: [], valeurs: {} });
});

router.post('/inscription', (req, res) => {
  const { nom_boutique, whatsapp, email, mot_de_passe, ville } = req.body;
  const erreurs = [];

  if (!nom_boutique || nom_boutique.trim().length < 2) {
    erreurs.push('Le nom de la boutique doit contenir au moins 2 caracteres.');
  }
  const whatsappChiffres = String(whatsapp || '').replace(/\D/g, '');
  if (whatsappChiffres.length < 9) {
    erreurs.push("Le numero WhatsApp n'est pas valide (indiquez l'indicatif pays, ex: 2376xxxxxxxx).");
  }
  if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
    erreurs.push("L'adresse email n'est pas valide.");
  }
  if (!mot_de_passe || mot_de_passe.length < 6) {
    erreurs.push('Le mot de passe doit contenir au moins 6 caracteres.');
  }
  if (email) {
    const existant = db.prepare('SELECT id FROM marchands WHERE email = ?').get(email.toLowerCase().trim());
    if (existant) erreurs.push('Un compte existe deja avec cet email. Connectez-vous plutot.');
  }

  if (erreurs.length) {
    return res.status(400).render('signup', { erreurs, valeurs: req.body });
  }

  let slug = creerSlug(nom_boutique);
  while (db.prepare('SELECT id FROM marchands WHERE slug = ?').get(slug)) {
    slug = creerSlug(nom_boutique);
  }

  const hash = bcrypt.hashSync(mot_de_passe, 10);
  const essaiExpireLe = new Date(Date.now() + JOURS_ESSAI * 24 * 60 * 60 * 1000).toISOString();

  const resultat = db.prepare(`
    INSERT INTO marchands (nom_boutique, slug, whatsapp, email, mot_de_passe_hash, ville, essai_expire_le)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(nom_boutique.trim(), slug, whatsappChiffres, email.toLowerCase().trim(), hash, (ville || '').trim(), essaiExpireLe);

  req.session.marchandId = resultat.lastInsertRowid;
  req.session.flash = { type: 'succes', message: `Bienvenue ! Votre boutique est prete. Vous avez ${JOURS_ESSAI} jours d'essai gratuit.` };
  res.redirect('/tableau-de-bord');
});

router.get('/connexion', (req, res) => {
  if (req.session.marchandId) return res.redirect('/tableau-de-bord');
  res.render('login', { erreur: null, email: '' });
});

router.post('/connexion', (req, res) => {
  const { email, mot_de_passe } = req.body;
  const marchand = db.prepare('SELECT * FROM marchands WHERE email = ?').get(String(email || '').toLowerCase().trim());

  if (!marchand || !bcrypt.compareSync(mot_de_passe || '', marchand.mot_de_passe_hash)) {
    return res.status(401).render('login', { erreur: 'Email ou mot de passe incorrect.', email });
  }

  req.session.marchandId = marchand.id;
  res.redirect('/tableau-de-bord');
});

router.post('/deconnexion', (req, res) => {
  req.session.destroy(() => res.redirect('/'));
});

module.exports = router;
